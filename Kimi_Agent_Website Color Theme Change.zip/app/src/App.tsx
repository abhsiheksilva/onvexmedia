import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Components
import Header from './components/Header';

// Sections
import HeroSection from './sections/HeroSection';
import ManifestoSection from './sections/ManifestoSection';
import PortfolioTeaserSection from './sections/PortfolioTeaserSection';
import ProcessTeaserSection from './sections/ProcessTeaserSection';
import PartnershipsSection from './sections/PartnershipsSection';
import ServicesSection from './sections/ServicesSection';
import PortfolioSection from './sections/PortfolioSection';
import BehindTheScenesSection from './sections/BehindTheScenesSection';
import ContactSection from './sections/ContactSection';
import BookingSection from './sections/BookingSection';
import FooterSection from './sections/FooterSection';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

function App() {
  // Global Scroll Snap Configuration
  useEffect(() => {
    // Wait for all ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter((st) => st.vars.pin)
        .sort((a, b) => a.start - b.start);

      const maxScroll = ScrollTrigger.maxScroll(window);

      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map((st) => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (allow small buffer)
            const inPinned = pinnedRanges.some(
              (r) => value >= r.start - 0.02 && value <= r.end + 0.02
            );

            // If not in a pinned section, allow free scroll
            if (!inPinned) return value;

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );

            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 100);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  // Refresh ScrollTrigger on resize
  useEffect(() => {
    const handleResize = () => {
      ScrollTrigger.refresh();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative bg-[#020617] min-h-screen">
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="relative">
        {/* Section 1: Hero - pin: true */}
        <HeroSection />

        {/* Section 2: Manifesto - pin: true */}
        <ManifestoSection />

        {/* Section 3: Portfolio Teaser - pin: true */}
        <PortfolioTeaserSection />

        {/* Section 4: Process Teaser - pin: true */}
        <ProcessTeaserSection />

        {/* Section 5: Partnerships - pin: true */}
        <PartnershipsSection />

        {/* Section 6: Services - pin: false (flowing) */}
        <ServicesSection />

        {/* Section 7: Portfolio - pin: false (flowing) */}
        <PortfolioSection />

        {/* Section 8: Behind The Scenes - pin: false (flowing) */}
        <BehindTheScenesSection />

        {/* Section 9: Contact - pin: true */}
        <ContactSection />

        {/* Section 10: Booking - pin: true */}
        <BookingSection />

        {/* Section 11: Footer - pin: false (flowing) */}
        <FooterSection />
      </main>
    </div>
  );
}

export default App;
