import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Twitter, Linkedin, Youtube, ArrowUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const quickLinks = [
  { label: 'Work', href: '#portfolio' },
  { label: 'Services', href: '#services' },
  { label: 'Contact', href: '#contact' },
  { label: 'Book', href: '#booking' },
];

const socialLinks = [
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

const FooterSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Content animation
      gsap.fromTo(
        contentRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer
      ref={sectionRef}
      className="section-flowing relative z-[110]"
    >
      {/* Background Image */}
      <div className="absolute inset-0 w-full h-full">
        <img
          src="/images/night_footer.jpg"
          alt="Night cityscape"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-[#020617]/80" />
      </div>

      {/* Content */}
      <div className="relative px-6 lg:px-[8vw] py-20 md:py-32">
        {/* Headline */}
        <div ref={headlineRef} className="mb-16 md:mb-24">
          <h2 className="headline-xl text-white">
            Thanks<br />
            <span className="text-[#00D4FF]">For Visiting</span>
          </h2>
        </div>

        {/* Footer Content */}
        <div
          ref={contentRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8"
        >
          {/* Contact Info */}
          <div>
            <h3 className="label-mono mb-6">Contact</h3>
            <div className="space-y-3">
              <a
                href="mailto:hello@onvex.media"
                className="block text-white hover:text-[#00D4FF] transition-colors"
              >
                hello@onvex.media
              </a>
              <a
                href="tel:+15550132488"
                className="block text-white hover:text-[#00D4FF] transition-colors"
              >
                +1 (555) 013-2488
              </a>
              <p className="text-[#94A3B8]">New York, NY</p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="label-mono mb-6">Quick Links</h3>
            <div className="space-y-3">
              {quickLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(link.href);
                  }}
                  className="block text-white hover:text-[#00D4FF] transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="label-mono mb-6">Follow Us</h3>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  onClick={(e) => {
                    e.preventDefault();
                    alert(`${social.label} link coming soon!`);
                  }}
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#00D4FF] transition-colors duration-300 group"
                  aria-label={social.label}
                >
                  <social.icon size={18} className="text-white group-hover:text-[#020617]" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[#94A3B8] text-sm">
            © {new Date().getFullYear()} Onvex Media. All rights reserved.
          </p>

          <div className="flex items-center gap-6">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                alert('Privacy Policy coming soon!');
              }}
              className="text-[#94A3B8] text-sm hover:text-white transition-colors"
            >
              Privacy Policy
            </a>
            <button
              onClick={scrollToTop}
              className="w-10 h-10 rounded-full bg-[#00D4FF] flex items-center justify-center hover:bg-[#33DDFF] transition-colors duration-300"
              aria-label="Scroll to top"
            >
              <ArrowUp size={18} className="text-[#020617]" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;
