import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Share2, Video, Palette, Download } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Share2,
    title: 'Social Media Management',
    description:
      'Content strategy, publishing, community, and reporting. We handle the full spectrum of your social presence.',
    tags: ['Strategy', 'Content', 'Analytics'],
  },
  {
    icon: Video,
    title: 'Video Editing',
    description:
      'Short-form, promos, ads, and platform-native cuts. From raw footage to polished final product.',
    tags: ['Editing', 'Color', 'Motion'],
  },
  {
    icon: Palette,
    title: 'Graphic Design',
    description:
      'Banners, identities, and campaign visuals. Design that communicates your brand essence.',
    tags: ['Branding', 'UI/UX', 'Print'],
  },
];

const ServicesSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards staggered animation
      const cards = cardsRef.current?.querySelectorAll('.service-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 80, opacity: 0, scale: 0.98 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 0.7,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="section-flowing bg-[#0F172A] py-20 md:py-32 z-[60]"
    >
      <div className="px-6 lg:px-[8vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-12 md:mb-16">
          <h2 className="headline-lg text-white mb-4">
            Services Built For<br />
            <span className="text-[#00D4FF]">Modern Brands</span>
          </h2>
          <p className="body-text max-w-xl text-white/70">
            Strategy, production, and design—delivered as a system, not a stack
            of tasks. Everything you need to elevate your brand.
          </p>
        </div>

        {/* Service Cards Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8"
        >
          {services.map((service, index) => (
            <div
              key={index}
              className="service-card card-service group cursor-pointer"
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-xl bg-[#020617] flex items-center justify-center mb-6 group-hover:bg-[#00D4FF] transition-colors duration-300">
                <service.icon
                  size={28}
                  className="text-white group-hover:text-[#020617] transition-colors duration-300"
                />
              </div>

              {/* Title */}
              <h3 className="text-xl font-bold text-[#020617] mb-3">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-[#020617]/70 text-sm leading-relaxed mb-6">
                {service.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {service.tags.map((tag, tagIndex) => (
                  <span
                    key={tagIndex}
                    className="px-3 py-1 bg-[#00D4FF]/10 rounded-full text-xs font-medium text-[#00D4FF]"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Download CTA */}
        <div className="mt-12 md:mt-16 text-center">
          <button
            onClick={() => alert('Service sheet download coming soon!')}
            className="inline-flex items-center gap-2 text-white font-medium text-sm uppercase tracking-wider group"
          >
            <Download size={16} />
            Download service sheet
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
