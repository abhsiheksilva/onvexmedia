import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ManifestoSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const paragraphRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      // Background scales in
      scrollTl.fromTo(
        bgRef.current,
        { scale: 1.14, opacity: 0.7 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      // Headline lines slide in from left
      const headlineLines = headlineRef.current?.querySelectorAll('.headline-line');
      if (headlineLines) {
        headlineLines.forEach((line, index) => {
          scrollTl.fromTo(
            line,
            { x: '-50vw', opacity: 0 },
            { x: 0, opacity: 1, ease: 'power2.out' },
            0.06 * index
          );
        });
      }

      // Paragraph fades in from bottom
      scrollTl.fromTo(
        paragraphRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'power2.out' },
        0.18
      );

      // SETTLE (30% - 70%): Hold position

      // EXIT (70% - 100%)
      scrollTl.fromTo(
        headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '-35vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        paragraphRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        bgRef.current,
        { x: 0, opacity: 1 },
        { x: '-10vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-20"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
      >
        <img
          src="/images/manifesto_street.jpg"
          alt="Urban street scene"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#020617]/80 via-[#020617]/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="absolute left-0 top-0 w-full h-full flex flex-col justify-center px-6 lg:px-[8vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-8 md:mb-12">
          <h2 className="headline-xl text-white">
            <span className="headline-line block">We Build</span>
            <span className="headline-line block">Brands</span>
            <span className="headline-line block text-[#00D4FF]">That Resonate</span>
          </h2>
        </div>

        {/* Paragraph */}
        <div ref={paragraphRef} className="max-w-lg">
          <p className="body-text text-lg mb-6">
            From first impression to lasting memory—our work turns attention into
            trust. We don't just create content; we build brand experiences that
            stick.
          </p>
          <a
            href="#services"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-white font-medium text-sm uppercase tracking-wider group"
          >
            See our process
            <ArrowRight
              size={16}
              className="transition-transform group-hover:translate-x-1"
            />
          </a>
        </div>
      </div>
    </section>
  );
};

export default ManifestoSection;
