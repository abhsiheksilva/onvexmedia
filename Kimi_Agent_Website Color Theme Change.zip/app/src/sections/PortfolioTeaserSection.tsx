import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, FileText } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const PortfolioTeaserSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      // Image slides in from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      );

      // Text content slides in from right
      const textElements = textRef.current?.children;
      if (textElements) {
        Array.from(textElements).forEach((el, index) => {
          scrollTl.fromTo(
            el,
            { x: '40vw', opacity: 0 },
            { x: 0, opacity: 1, ease: 'power2.out' },
            0.04 * index
          );
        });
      }

      // SETTLE (30% - 70%): Hold position

      // EXIT (70% - 100%)
      scrollTl.fromTo(
        imageRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        textRef.current,
        { x: 0, opacity: 1 },
        { x: '22vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#020617] z-30"
    >
      {/* Left Image */}
      <div
        ref={imageRef}
        className="absolute left-0 top-0 w-full md:w-[55vw] h-full"
      >
        <img
          src="/images/work_portrait.jpg"
          alt="Creative work"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for mobile */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#020617] md:block hidden" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent md:hidden" />
      </div>

      {/* Right Text Content */}
      <div
        ref={textRef}
        className="absolute right-0 top-0 w-full md:w-[45vw] h-full flex flex-col justify-center px-6 lg:px-[4vw] md:pl-0"
      >
        <div className="md:bg-transparent bg-[#020617]/90 backdrop-blur-sm md:p-0 p-6 rounded-xl">
          {/* Headline */}
          <h2 className="headline-xl text-white mb-6 md:mb-8">
            <span className="block">Work</span>
            <span className="block">That</span>
            <span className="block text-[#00D4FF]">Speaks</span>
          </h2>

          {/* Subheadline */}
          <p className="body-text max-w-md mb-8">
            Campaigns, content systems, and brand worlds—built for performance.
            Every piece is designed to engage, convert, and leave a lasting
            impression.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#portfolio"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#portfolio')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-primary flex items-center justify-center gap-2 group"
            >
              Explore Projects
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </a>
            <button
              onClick={() => alert('Deck request feature coming soon!')}
              className="btn-secondary flex items-center justify-center gap-2 group"
            >
              <FileText size={16} />
              Request a deck
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PortfolioTeaserSection;
