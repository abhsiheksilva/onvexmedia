import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const metaRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Image entrance
      tl.fromTo(
        imageRef.current,
        { opacity: 0, x: '12vw', scale: 1.06 },
        { opacity: 1, x: 0, scale: 1, duration: 1.1 },
        0
      );

      // Label entrance
      tl.fromTo(
        labelRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.2
      );

      // Headline lines entrance
      const headlineLines = headlineRef.current?.querySelectorAll('.headline-line');
      if (headlineLines) {
        tl.fromTo(
          headlineLines,
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.7, stagger: 0.08 },
          0.3
        );
      }

      // Subheadline entrance
      tl.fromTo(
        subheadlineRef.current,
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.6
      );

      // CTA buttons entrance
      tl.fromTo(
        ctaRef.current,
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.7
      );

      // Meta entrance
      tl.fromTo(
        metaRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.8
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([imageRef.current, headlineRef.current, subheadlineRef.current, ctaRef.current, metaRef.current], {
              opacity: 1,
              x: 0,
              y: 0,
              scale: 1,
            });
          },
        },
      });

      // SETTLE phase (0% - 70%): Hold position
      // No animation needed - elements stay in place

      // EXIT phase (70% - 100%)
      // Headline block exits left
      scrollTl.fromTo(
        headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '-40vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Subheadline exits left
      scrollTl.fromTo(
        subheadlineRef.current,
        { x: 0, opacity: 1 },
        { x: '-35vw', opacity: 0, ease: 'power2.in' },
        0.72
      );

      // CTA exits left
      scrollTl.fromTo(
        ctaRef.current,
        { x: 0, opacity: 1 },
        { x: '-30vw', opacity: 0, ease: 'power2.in' },
        0.74
      );

      // Image exits right
      scrollTl.fromTo(
        imageRef.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '18vw', scale: 1.08, opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Meta exits down
      scrollTl.fromTo(
        metaRef.current,
        { y: 0, opacity: 1 },
        { y: '6vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Label fades
      scrollTl.fromTo(
        labelRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#020617] z-10"
    >
      {/* Vignette overlay */}
      <div className="vignette" />

      {/* Hero Image (Right side) */}
      <div
        ref={imageRef}
        className="absolute right-0 top-0 w-full md:w-[48vw] h-full"
      >
        <img
          src="/images/hero_portrait.jpg"
          alt="Creative professional"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for mobile */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#020617] via-[#020617]/60 to-transparent md:hidden" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent md:hidden" />
      </div>

      {/* Content (Left side) */}
      <div className="absolute left-0 top-0 w-full md:w-[52vw] h-full flex flex-col justify-center px-6 lg:px-[8vw]">
        {/* Micro label */}
        <span
          ref={labelRef}
          className="label-mono mb-6 md:mb-8"
        >
          Creative Agency
        </span>

        {/* Headline */}
        <div ref={headlineRef} className="mb-6 md:mb-8">
          <h1 className="headline-xl text-white">
            <span className="headline-line block">Crafting</span>
            <span className="headline-line block text-[#00D4FF]">Visuals</span>
            <span className="headline-line block">That Connect</span>
          </h1>
        </div>

        {/* Subheadline */}
        <p
          ref={subheadlineRef}
          className="body-text max-w-md mb-8 md:mb-10"
        >
          Strategy-led content for brands that want to stand out—fast. We craft
          visuals that tell your story and elevate your presence.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => scrollToSection('#portfolio')}
            className="btn-primary flex items-center justify-center gap-2 group"
          >
            <Play size={16} className="transition-transform group-hover:scale-110" />
            View Work
          </button>
          <button
            onClick={() => scrollToSection('#booking')}
            className="btn-secondary flex items-center justify-center gap-2 group"
          >
            Start a Project
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>

      {/* Bottom meta */}
      <div
        ref={metaRef}
        className="absolute left-6 lg:left-[8vw] bottom-8 md:bottom-[8vh]"
      >
        <p className="font-mono text-xs text-[#64748B] uppercase tracking-wider">
          Onvex Media — Social · Video · Design
        </p>
      </div>
    </section>
  );
};

export default HeroSection;
