import { useState, useRef, useLayoutEffect, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight, Camera } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const btsImages = [
  {
    src: '/images/bts_office.jpg',
    title: 'Our Creative Studio',
    description: 'Where ideas come to life',
  },
  {
    src: '/images/bts_production.jpg',
    title: 'Video Production',
    description: 'Professional filming setup',
  },
  {
    src: '/images/bts_team.jpg',
    title: 'Team Brainstorming',
    description: 'Collaborative sessions',
  },
  {
    src: '/images/portfolio_video.jpg',
    title: 'Post-Production',
    description: 'Editing and color grading',
  },
];

const BehindTheScenesSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Carousel animation
      gsap.fromTo(
        carouselRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: carouselRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  // Auto-play carousel
  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % btsImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    // Resume auto-play after 10 seconds
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToPrev = () => {
    goToSlide((currentIndex - 1 + btsImages.length) % btsImages.length);
  };

  const goToNext = () => {
    goToSlide((currentIndex + 1) % btsImages.length);
  };

  return (
    <section
      ref={sectionRef}
      id="bts"
      className="section-flowing bg-[#020617] py-20 md:py-32 z-[80]"
    >
      <div className="px-6 lg:px-[8vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-12 md:mb-16 text-center">
          <span className="label-mono mb-4 block">
            <Camera size={14} className="inline mr-2" />
            Behind The Scenes
          </span>
          <h2 className="headline-lg text-white mb-4">
            How We<br />
            <span className="text-[#00D4FF]">Create Magic</span>
          </h2>
          <p className="body-text max-w-xl mx-auto">
            Take a peek into our world. From brainstorming sessions to final
            edits, see how we bring brands to life.
          </p>
        </div>

        {/* Carousel */}
        <div ref={carouselRef} className="relative max-w-5xl mx-auto">
          {/* Main Image */}
          <div className="relative aspect-[16/9] rounded-2xl overflow-hidden">
            {btsImages.map((image, index) => (
              <div
                key={index}
                className={`absolute inset-0 transition-opacity duration-500 ${
                  index === currentIndex ? 'opacity-100' : 'opacity-0'
                }`}
              >
                <img
                  src={image.src}
                  alt={image.title}
                  className="w-full h-full object-cover"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#020617]/80 via-transparent to-transparent" />

                {/* Caption */}
                <div className="absolute bottom-6 left-6 md:bottom-8 md:left-8">
                  <h3 className="text-xl md:text-2xl font-bold text-white mb-1">
                    {image.title}
                  </h3>
                  <p className="text-[#94A3B8] text-sm">{image.description}</p>
                </div>
              </div>
            ))}

            {/* Navigation Arrows */}
            <button
              onClick={goToPrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-[#020617]/60 backdrop-blur-sm flex items-center justify-center hover:bg-[#00D4FF] transition-colors duration-300 group"
            >
              <ChevronLeft size={24} className="text-white group-hover:text-[#020617]" />
            </button>
            <button
              onClick={goToNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-[#020617]/60 backdrop-blur-sm flex items-center justify-center hover:bg-[#00D4FF] transition-colors duration-300 group"
            >
              <ChevronRight size={24} className="text-white group-hover:text-[#020617]" />
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-6">
            {btsImages.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex
                    ? 'w-8 bg-[#00D4FF]'
                    : 'bg-white/30 hover:bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BehindTheScenesSection;
