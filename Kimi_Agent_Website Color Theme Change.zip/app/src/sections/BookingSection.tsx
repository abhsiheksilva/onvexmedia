import { useState, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, Clock, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  'Social Media Management',
  'Video Editing',
  'Graphic Design',
  'Full Brand Package',
];

const BookingSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: '',
    date: '',
    notes: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const formCardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      // Background scales in
      scrollTl.fromTo(
        bgRef.current,
        { scale: 1.12, opacity: 0.7 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      // Headline slides in from left
      scrollTl.fromTo(
        headlineRef.current,
        { x: '-40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      );

      // Form card slides in from right
      scrollTl.fromTo(
        formCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0.1
      );

      // SETTLE (30% - 70%): Hold position

      // EXIT (70% - 100%)
      scrollTl.fromTo(
        headlineRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        formCardRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        bgRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setSubmitMessage('Booking request sent! We will confirm within a few hours.');
    setFormData({
      name: '',
      email: '',
      service: '',
      date: '',
      notes: '',
    });
    setIsSubmitting(false);

    setTimeout(() => setSubmitMessage(''), 5000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section
      ref={sectionRef}
      id="booking"
      className="section-pinned z-[100]"
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0 w-full h-full">
        <img
          src="/images/cafe_booking.jpg"
          alt="Cafe interior"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-[#020617]/60" />
      </div>

      {/* Content Container */}
      <div className="absolute inset-0 flex flex-col md:flex-row items-center justify-center px-6 lg:px-[8vw] gap-8 md:gap-12">
        {/* Left: Headline */}
        <div ref={headlineRef} className="w-full md:w-1/2">
          <span className="label-mono mb-4 block">
            <Calendar size={14} className="inline mr-2" />
            Schedule a Call
          </span>
          <h2 className="headline-xl text-white mb-6">
            Book<br />
            <span className="text-[#00D4FF]">A Session</span>
          </h2>
          <p className="body-text max-w-md mb-8">
            Choose a time that works for you. We'll confirm within a few hours.
            Let's discuss how we can help elevate your brand.
          </p>

          {/* Features */}
          <div className="space-y-4">
            {[
              'Free 30-minute consultation',
              'No commitment required',
              'Personalized strategy discussion',
            ].map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#00D4FF] flex items-center justify-center">
                  <Check size={14} className="text-[#020617]" />
                </div>
                <span className="text-white">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Form Card */}
        <div ref={formCardRef} className="w-full md:w-1/2 max-w-lg">
          <div className="bg-[#020617]/80 backdrop-blur-lg border border-white/10 rounded-2xl p-6 md:p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Name */}
              <div>
                <label className="label-mono block mb-2">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="input-field"
                  placeholder="Your name"
                />
              </div>

              {/* Email */}
              <div>
                <label className="label-mono block mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="input-field"
                  placeholder="your@email.com"
                />
              </div>

              {/* Service */}
              <div>
                <label className="label-mono block mb-2">Service</label>
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  required
                  className="input-field appearance-none cursor-pointer"
                >
                  <option value="">Select a service</option>
                  {services.map((service, index) => (
                    <option key={index} value={service}>
                      {service}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="label-mono block mb-2">Preferred Date</label>
                <div className="relative">
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    required
                    className="input-field"
                    min={new Date().toISOString().split('T')[0]}
                  />
                  <Calendar
                    size={18}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-[#64748B]/50 pointer-events-none"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="label-mono block mb-2">Notes (Optional)</label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={3}
                  className="input-field resize-none"
                  placeholder="Any specific topics you'd like to discuss..."
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  'Booking...'
                ) : (
                  <>
                    <Clock size={16} />
                    Book Consultation
                  </>
                )}
              </button>

              {/* Success Message */}
              {submitMessage && (
                <p className="text-center text-[#00D4FF] text-sm">
                  {submitMessage}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;
