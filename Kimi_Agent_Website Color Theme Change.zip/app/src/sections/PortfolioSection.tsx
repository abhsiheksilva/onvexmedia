import { useState, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { X, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const portfolioItems = [
  {
    id: 1,
    title: 'Social Media Campaign',
    category: 'Social Media',
    image: '/images/portfolio_social.jpg',
    description:
      'A comprehensive social media campaign that increased engagement by 340% across Instagram, TikTok, and LinkedIn.',
  },
  {
    id: 2,
    title: 'Brand Video Production',
    category: 'Video Editing',
    image: '/images/portfolio_video.jpg',
    description:
      'Cinematic brand story video with professional color grading and motion graphics.',
  },
  {
    id: 3,
    title: 'Visual Identity System',
    category: 'Graphic Design',
    image: '/images/portfolio_design.jpg',
    description:
      'Complete brand identity including logo, business cards, and marketing collateral.',
  },
  {
    id: 4,
    title: 'Creative Process',
    category: 'Behind the Scenes',
    image: '/images/bts_production.jpg',
    description:
      'Behind-the-scenes look at our professional video production setup.',
  },
  {
    id: 5,
    title: 'Team Collaboration',
    category: 'Behind the Scenes',
    image: '/images/bts_team.jpg',
    description:
      'Our creative team brainstorming the next big campaign.',
  },
  {
    id: 6,
    title: 'Modern Workspace',
    category: 'Behind the Scenes',
    image: '/images/bts_office.jpg',
    description:
      'Our state-of-the-art creative studio where ideas come to life.',
  },
];

const PortfolioSection = () => {
  const [selectedItem, setSelectedItem] = useState<typeof portfolioItems[0] | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Grid items staggered animation
      const items = gridRef.current?.querySelectorAll('.portfolio-item');
      if (items) {
        gsap.fromTo(
          items,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="portfolio"
      className="section-flowing bg-[#020617] py-20 md:py-32 z-[70]"
    >
      <div className="px-6 lg:px-[8vw]">
        {/* Headline */}
        <div ref={headlineRef} className="mb-12 md:mb-16">
          <span className="label-mono mb-4 block">Our Work</span>
          <h2 className="headline-lg text-white mb-4">
            Selected<br />
            <span className="text-[#00D4FF]">Projects</span>
          </h2>
          <p className="body-text max-w-xl">
            A curated selection of our recent work across social media, video,
            and design. Each project tells a unique story.
          </p>
        </div>

        {/* Portfolio Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {portfolioItems.map((item) => (
            <div
              key={item.id}
              className="portfolio-item group relative aspect-[4/3] rounded-xl overflow-hidden cursor-pointer"
              onClick={() => setSelectedItem(item)}
            >
              {/* Image */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Content */}
              <div className="absolute inset-0 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="label-mono text-[#00D4FF] mb-2">
                  {item.category}
                </span>
                <h3 className="text-xl font-bold text-white">
                  {item.title}
                </h3>
              </div>

              {/* Hover Icon */}
              <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#00D4FF] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                <ExternalLink size={18} className="text-[#020617]" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Lightbox */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-[1000] bg-[#020617]/95 backdrop-blur-lg flex items-center justify-center p-4 md:p-8"
          onClick={() => setSelectedItem(null)}
        >
          {/* Close Button */}
          <button
            className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#00D4FF] transition-colors duration-300"
            onClick={() => setSelectedItem(null)}
          >
            <X size={24} className="text-white hover:text-[#020617]" />
          </button>

          {/* Modal Content */}
          <div
            className="max-w-5xl w-full bg-[#0F172A] rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Image */}
            <div className="aspect-video w-full">
              <img
                src={selectedItem.image}
                alt={selectedItem.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Content */}
            <div className="p-6 md:p-8">
              <span className="label-mono text-[#00D4FF] mb-3 block">
                {selectedItem.category}
              </span>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                {selectedItem.title}
              </h3>
              <p className="body-text text-base">
                {selectedItem.description}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default PortfolioSection;
