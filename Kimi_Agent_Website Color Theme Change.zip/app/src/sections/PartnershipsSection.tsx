import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Users } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const PartnershipsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      // Image slides in from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      );

      // Text content slides in from right
      const textElements = textRef.current?.children;
      if (textElements) {
        Array.from(textElements).forEach((el, index) => {
          scrollTl.fromTo(
            el,
            { x: '40vw', opacity: 0 },
            { x: 0, opacity: 1, ease: 'power2.out' },
            0.04 * index
          );
        });
      }

      // SETTLE (30% - 70%): Hold position

      // EXIT (70% - 100%)
      scrollTl.fromTo(
        imageRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        textRef.current,
        { x: 0, opacity: 1 },
        { x: '22vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-[#020617] z-50"
    >
      {/* Left Image */}
      <div
        ref={imageRef}
        className="absolute left-0 top-0 w-full md:w-[55vw] h-full"
      >
        <img
          src="/images/collaborate_portrait.jpg"
          alt="Team collaboration"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for mobile */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#020617] md:block hidden" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent md:hidden" />
      </div>

      {/* Right Text Content */}
      <div
        ref={textRef}
        className="absolute right-0 top-0 w-full md:w-[45vw] h-full flex flex-col justify-center px-6 lg:px-[4vw] md:pl-0"
      >
        <div className="md:bg-transparent bg-[#020617]/90 backdrop-blur-sm md:p-0 p-6 rounded-xl">
          {/* Headline */}
          <h2 className="headline-xl text-white mb-6 md:mb-8">
            <span className="block">Collaborate</span>
            <span className="block">And</span>
            <span className="block text-[#00D4FF]">Grow</span>
          </h2>

          {/* Subheadline */}
          <p className="body-text max-w-md mb-8">
            We partner with teams who want clarity, speed, and work they're proud
            to share. Together, we build brands that stand out in crowded markets.
          </p>

          {/* CTA */}
          <a
            href="#bts"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#bts')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="btn-primary inline-flex items-center gap-2 group"
          >
            <Users size={16} />
            Meet the team
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default PartnershipsSection;
